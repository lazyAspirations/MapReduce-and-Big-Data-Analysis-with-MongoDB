import random
from pymongo import MongoClient

# Connexion à la base de données
# si vous avez une base de données sans authentification, utilisez :
client = MongoClient("mongodb://localhost:27017/")

# si vous avez une base de données avec authentification, utilisez :
# client = MongoClient(
#    "mongodb://admin:admin123@localhost:27017/",
#    authSource="admin"
# )
try:
    dbs = client.list_database_names()
    print("Connexion réussie ! Bases de données disponibles :")
    print(dbs)
except Exception as e:
    print("Erreur lors de la connexion :", e)


db = client["universite"]
collection = db["transactions_tp4"]

categories = ["Informatique", "Electronique", "Telecom", "IA"]

liste_transactions = []
for i in range(10000):
    doc = {
        "categorie": random.choice(categories),
        "montant": random.randint(50, 1000),
        "note_client": random.randint(1, 5),
        "annee": random.choice([2022, 2023, 2024])
    }
    liste_transactions.append(doc)

# Insertion massive
collection.insert_many(liste_transactions)
print("✅ Succès : 10 000 transactions insérées.")
