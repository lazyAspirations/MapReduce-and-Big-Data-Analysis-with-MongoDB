from pymongo import MongoClient


# Connexion à la base de données
# si vous avez une base de données sans authentification, utilisez :
client = MongoClient("mongodb://localhost:27017/")

# si vous avez une base de données avec authentification, utilisez :
# client = MongoClient(
#    "mongodb://admin:admin123@localhost:27017/",
#    authSource="admin"
# )
try:
    dbs = client.list_database_names()
    print("Connexion réussie ! Bases de données disponibles :")
    print(dbs)
except Exception as e:
    print("Erreur lors de la connexion :", e)


db = client["universite"]
collection = db["comments"]

# --- Vérification du nombre de documents ---
doc_count = collection.count_documents({})
print(f"Nombre de documents dans comments collections est:  : {doc_count}")

print("Analyse des mots fréquents en cours...")

if doc_count == 0:
    print("La collection est vide. Ajoutez des documents avant l'analyse.")
else:
    # --- Aggregation Word Count ---
    pipeline = [
        # diviser nom en mots
        {"$project": {"words": {"$split": ["$text", " "]}}},
        # séparer chaque mot
        {"$unwind": "$words"},
        {"$group": {"_id": "$words", "count": {"$sum": 1}}},  # compter chaque mot
        # trier par fréquence
        {"$sort": {"count": -1}}
    ]

    result = collection.aggregate(pipeline)

    # --- Affichage des 10 premiers résultats ---
    print("\nTop 10 mots les plus fréquents :")
    for i, doc in enumerate(result):
        if i >= 10:
            break
        print(doc)
