// ==========================================================
// CONFIGURATION ET ACCÈS AUX DONNÉES
// ==========================================================

// La commande getSiblingDB permet de basculer sur la base "universite" 
// sans utiliser la commande interactive "use universite". 
// C'est indispensable pour que le script soit autonome.
db = db.getSiblingDB("universite");

// Affichage d'un échantillon pour comprendre la structure des données sources
print("--- APERÇU D'UN DOCUMENT SOURCE (transactions_tp4) ---");
printjson(db.transactions_tp4.findOne()); 
// Note : Le document contient les champs : _id, montant, categorie, date.
print("------------------------------------------------------\n");

// ==========================================================
// 1. MÉTHODE MAPREDUCE (Approche Traditionnelle)
// ==========================================================

// La fonction Map : Parcourt chaque document et "émet" (emit) 
// la catégorie comme clé et le montant comme valeur.
var mapFn = function() {
    emit(this.categorie, { total: this.montant, count: 1 });
};

// La fonction Reduce : Reçoit une clé (catégorie) et un tableau de valeurs.
// Elle fusionne les données pour calculer la somme et le nombre.
var reduceFn = function(key, values) {
    var res = { total: 0, count: 0 };
    values.forEach(function(v) {
        res.total += v.total;
        res.count += v.count;
    });
    return res;
};

print("Lancement de MapReduce...");
var startMR = new Date();
// MapReduce stocke obligatoirement le résultat dans une nouvelle collection ("mr_results")
db.transactions_tp4.mapReduce(mapFn, reduceFn, { out: "mr_results" });
var timeMR = new Date() - startMR;

// Affichage du résultat MapReduce
print("Résultat MapReduce (extrait) :");
db.mr_results.find().limit(2).forEach(printjson);

// ==========================================================
// 2. MÉTHODE AGGREGATION FRAMEWORK (Approche Native)
// ==========================================================

print("\nLancement de l'Aggregation...");
var startAgg = new Date();

// Le pipeline définit les étapes de transformation des données.
// $group : Regroupe par catégorie et applique les accumulateurs ($sum).
var aggCursor = db.transactions_tp4.aggregate([
    { 
        $group: { 
            _id: "$categorie", 
            total: { $sum: "$montant" }, 
            count: { $sum: 1 } 
        } 
    }
]);

// .toArray() force l'extraction de toutes les données du curseur pour mesurer le temps réel
var aggRes = aggCursor.toArray(); 
var timeAgg = new Date() - startAgg;

// Affichage du résultat Aggregation
print("Résultat Aggregation (extrait) :");
printjson(aggRes.slice(0, 2));

// ==========================================================
// 3. BILAN ET COMPARAISON
// ==========================================================

print("\n" + "=".repeat(40));
print("      RÉSULTATS DU BENCHMARK");
print("=".repeat(40));
print("Temps MapReduce   : " + timeMR + " ms");
print("Temps Aggregation : " + timeAgg + " ms");
print("-".repeat(40));
var ratio = (timeMR / timeAgg).toFixed(2);
print("L'Aggregation est " + ratio + " fois plus rapide.");
print("=".repeat(40));