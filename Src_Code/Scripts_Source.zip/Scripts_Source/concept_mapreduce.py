# Simulation pédagogique du concept MapReduce
from collections import defaultdict

# --- Données d'entrée ---
text = """
Les étudiants de M1 DS&NL Univ Blida 1
Les étudiants de M1 DS&NL
"""

# --- Phase 1 : MAP ---
map_output = []
for line in text.strip().split("\n"):
    words = line.split()
    for word in words:
        map_output.append((word, 1))

print("=== SORTIE PHASE MAP ===")
print(map_output)

# --- Phase 2 : SHUFFLE & SORT ---
shuffle_dict = defaultdict(list)
for key, value in map_output:
    shuffle_dict[key].append(value)

print("\n=== PHASE SHUFFLE & SORT ===")
for key, values in shuffle_dict.items():
    print(f"{key} -> {values}")

# --- Phase 3 : REDUCE ---
reduce_output = {}
for key, values in shuffle_dict.items():
    reduce_output[key] = sum(values)

print("\n=== RÉSULTAT FINAL (REDUCE) ===")
for key, count in reduce_output.items():
    print(f"{key} : {count}")
