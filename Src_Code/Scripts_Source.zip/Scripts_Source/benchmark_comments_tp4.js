// ==========================================================
// CONFIGURATION SUR UN VOLUME DE 50,000 DOCUMENTS
// ==========================================================
db = db.getSiblingDB("universite");

// Vérification du volume de données
var count = db.comments.countDocuments();
print("--- ANALYSE DE LA COLLECTION 'comments' (" + count + " documents) ---");

// ==========================================================
// 1. MÉTHODE MAPREDUCE (Traitement par mots)
// ==========================================================

// Map : Séparer le texte par espaces et émettre chaque mot avec un compteur de 1
var mapWords = function() {
    var words = this.text.split(" ");
    for (var i = 0; i < words.length; i++) {
        emit(words[i], 1);
    }
};

// Reduce : Sommer les occurrences de chaque mot
var reduceWords = function(key, values) {
    return Array.sum(values);
};

print("\nLancement MapReduce (Word Count)...");
var startMR = new Date();
db.comments.mapReduce(mapWords, reduceWords, { out: "word_count_mr" });
var timeMR = new Date() - startMR;

print("Extrait résultat MapReduce :");
db.word_count_mr.find().sort({value: -1}).limit(3).forEach(printjson);

// ==========================================================
// 2. MÉTHODE AGGREGATION (Traitement par mots)
// ==========================================================

print("\nLancement Aggregation (Word Count)...");
var startAgg = new Date();

var aggRes = db.comments.aggregate([
    { $project: { words: { $split: ["$text", " "] } } },
    { $unwind: "$words" },
    { $group: { _id: "$words", count: { $sum: 1 } } },
    { $sort: { count: -1 } },
    { $limit: 10 }
], { allowDiskUse: true }).toArray(); // allowDiskUse est crucial ici pour 50k docs

var timeAgg = new Date() - startAgg;

print("Extrait résultat Aggregation :");
printjson(aggRes.slice(0, 3));

// ==========================================================
// 3. BILAN FINAL
// ==========================================================

print("\n" + "=".repeat(40));
print("      BENCHMARK SUR 50,000 DOCUMENTS");
print("=".repeat(40));
print("Temps MapReduce   : " + timeMR + " ms");
print("Temps Aggregation : " + timeAgg + " ms");
var ratio = (timeMR / timeAgg).toFixed(2);
print("Performance : Aggregation est " + ratio + "x plus rapide.");
print("=".repeat(40));